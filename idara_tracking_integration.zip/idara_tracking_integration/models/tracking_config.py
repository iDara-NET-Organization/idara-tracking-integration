# Config model placeholder
