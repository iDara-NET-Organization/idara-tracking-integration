# Device model placeholder
